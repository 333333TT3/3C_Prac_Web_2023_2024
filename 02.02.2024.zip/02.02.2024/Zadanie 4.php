Zadanie 2

Warning: Undefined array key "adres" in C:\xampp\htdocs\02.02.2024\Zadanie2.php on line 12
Rejestracja zakończona sukcesem! Dane ucznia:
Imię: Antoni
Nazwisko: Kubicki
Wiek: 17
Klasa: 3c
Email: xxx@xxx.com

Warning: Undefined variable $adres in C:\xampp\htdocs\02.02.2024\Zadanie2.php on line 20
Adres:

Zadanie 3

Błąd: "Wypełnij wszystkie pola formularza!"